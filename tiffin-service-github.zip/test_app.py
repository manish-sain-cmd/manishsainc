from __future__ import annotations

import os
import unittest

os.environ["MONGODB_URI"] = "mongomock://demo"
os.environ["SECRET_KEY"] = "test"

from app import create_app


class OwnerConsoleTests(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.client = self.app.test_client()

    def _register(self):
        return self.client.post(
            "/register",
            data={"name": "Owner", "email": "owner@kitchen.test", "password": "secret1"},
            follow_redirects=True,
        )

    def test_landing_page_is_public(self):
        home = self.client.get("/")
        self.assertEqual(home.status_code, 200)
        self.assertIn(b"Target audience", home.data)
        self.assertIn(b"Three features we would build next", home.data)

    def test_subscribe_pause_and_month_bill(self):
        self._register()
        ledger = self.client.get("/app")
        self.assertEqual(ledger.status_code, 200)
        self.assertIn(b"Subscribe", ledger.data)

        self.client.post(
            "/subscribe",
            data={
                "name": "Asha",
                "phone": "9876543210",
                "plan_name": "Home-style veg",
                "subscribed_on": "2026-09-01",
            },
            follow_redirects=True,
        )
        self.client.post(
            "/pause",
            data={"phone": "9876543210", "start": "2026-09-14", "end": "2026-09-18"},
            follow_redirects=True,
        )
        lookup = self.client.get("/lookup?phone=9876543210&as_of=2026-09-17")
        self.assertEqual(lookup.status_code, 200)
        self.assertIn(b"paused", lookup.data)
        self.assertIn(b"2318.18", lookup.data)

        bills = self.client.get("/bills?year=2026&month=9")
        self.assertIn(b"Asha", bills.data)
        self.assertIn(b"17 / 22", bills.data)

        search = self.client.get("/app?q=Asha&sort=name&order=asc&page=1")
        self.assertIn(b"Asha", search.data)

    def test_rest_register_search_and_bill(self):
        created = self.client.post(
            "/api/register",
            json={"name": "Rina", "email": "rina@kitchen.test", "password": "secret1"},
        )
        self.assertEqual(created.status_code, 201)
        self.client.post(
            "/api/customers",
            json={
                "name": "Asha",
                "phone": "9876543210",
                "plan_name": "Home-style veg",
                "subscribed_on": "2026-09-01",
            },
        )
        listed = self.client.get("/api/customers?q=98765&sort=name&order=asc&page=1&per_page=10")
        payload = listed.get_json()
        self.assertEqual(payload["total"], 1)
        self.assertEqual(payload["items"][0]["phone"], "9876543210")
        bill = self.client.get("/api/bills?year=2026&month=9&sort=amount&order=desc")
        self.assertEqual(bill.get_json()["items"][0]["days_served"], 22)

    def test_clock_notifies_active_weekday_not_paused(self):
        self.client.post(
            "/api/register",
            json={"name": "Rina", "email": "clock@kitchen.test", "password": "secret1"},
        )
        self.client.post(
            "/api/customers",
            json={
                "name": "Asha",
                "phone": "9876543210",
                "plan_name": "Home-style veg",
                "subscribed_on": "2026-09-01",
            },
        )
        self.client.post(
            "/api/customers",
            json={
                "name": "Ravi",
                "phone": "9123456780",
                "plan_name": "Home-style veg",
                "subscribed_on": "2026-09-01",
            },
        )
        self.client.post("/api/customers/9123456780/pause", json={"start": "2026-09-14"})
        clock = self.client.post("/clock", json={"date": "2026-09-17"})
        self.assertEqual(clock.status_code, 200)
        phones = {row["phone"] for row in clock.get_json()["notified"]}
        self.assertEqual(phones, {"9876543210"})
        outbox = self.client.get("/outbox").get_json()
        self.assertEqual({row["phone"] for row in outbox}, {"9876543210"})
        weekend = self.client.post("/clock", json={"date": "2026-09-19"})
        self.assertEqual(weekend.get_json()["count"], 0)

    def test_transfer_splits_month_bill(self):
        self.client.post(
            "/api/register",
            json={"name": "Rina", "email": "xfer@kitchen.test", "password": "secret1"},
        )
        self.client.post(
            "/api/customers",
            json={
                "name": "Asha",
                "phone": "9876543210",
                "plan_name": "Home-style veg",
                "subscribed_on": "2026-09-01",
            },
        )
        moved = self.client.post(
            "/transfer",
            json={
                "from_phone": "9876543210",
                "name": "Ravi",
                "phone": "9123456780",
                "on": "2026-09-16",
            },
        )
        self.assertEqual(moved.status_code, 200)
        self.assertEqual(moved.get_json()["to"]["phone"], "9123456780")
        bills = self.client.get("/api/bills?year=2026&month=9").get_json()["items"]
        by_phone = {row["phone"]: row for row in bills}
        self.assertEqual(by_phone["9876543210"]["days_served"] + by_phone["9123456780"]["days_served"], 22)
        self.assertEqual(
            float(by_phone["9876543210"]["amount"]) + float(by_phone["9123456780"]["amount"]),
            3000.0,
        )

    def test_import_messy_list_report(self):
        self.client.post(
            "/api/register",
            json={"name": "Rina", "email": "import@kitchen.test", "password": "secret1"},
        )
        report = self.client.post(
            "/import",
            json=[
                {"name": "Asha", "phone": "9876543210", "plan_name": "Home-style veg", "subscribed_on": "16/09/2026"},
                {"name": "Asha dup", "phone": "+91-9876543210", "plan": "Home-style veg", "date": "2026-09-16"},
                {"name": "Ravi", "phone": "9123456780", "subscribed_on": "16 Sep 2026"},
                {"name": "", "phone": "9000000000", "subscribed_on": "2026-09-01"},
                {"name": "Blank date", "phone": "9000000001", "subscribed_on": ""},
            ],
        ).get_json()
        self.assertEqual(len(report["imported"]), 2)
        self.assertEqual(len(report["deduped"]), 1)
        self.assertEqual(len(report["rejected"]), 2)


if __name__ == "__main__":
    unittest.main()
